﻿# TAXI247
To set Up the API The Environment used is NODE JS

You can download Node.js runtime from  https://nodejs.org/en/download/
After installing this runtime

1.	Look at the .env_sample and replicate same for the .env File (I will send the Keys to you in a mail)
2.	From Nodejs command, navigate to the project Folder and execute the command
     Project path> node app
	This will start the server on the port 3000
	So the default url will be  http://localhost:3000
3.	Get any API testing tool eg POSTMAN https://www.getpostman.com/downloads/
	I have tried to add asimple Html Page to help in the testing but I think time is not at my side so is not complete the file is called Dashboard_Interview.html in the project folder

Below are sample requests and responses, The URLs ends with the route Names
Invoices
Drivers
Trips
Riders
Drivers_Available
Drivers_Closer

Example  below   (remember to check on the Port




POST 
 http://localhost:3000/drivers

Request  Body
{
"Name":"New Savoiur Mensah",
"LocationCode":"SAV1234",
"Loc_Discription":"Dodowa Pilla 2",
"Loc_Latitude":"236",
"Loc_Longitude":"9"
}

Response
{
    "status": "success",
    "message": "Driver Created successfully"
}








GET
   URL  http://localhost:3000/invoices



Response     

    "status": "success",
    "message": "List of Invoices",
    "InvoiceList": [
        {
            "InvoiceId": 1,
            "TripId": 1,
            "Amount": 100,
            "Driver": "Godwin Mensah Kumash",
            "Rider": "Savoiur Mensah",
            "StartDateTime": "2019-09-27",
            "EndDateTime": "2019-09-27",
            "request": {
                "type": "GET",
                "url": "http://localhost:1337/Invoices/1"
            }
        }
  
    ]
 





GET
   URL   http://localhost:3000/riders

      Response
      {
    "status": "success",
    "message": "List of Riders",
    "RiderList": [
        {
            "RidersId": 1,
            "Name": "Savoiur Mensah",
            "request": {
                "type": "GET",
                "url": "http://localhost:1337/riders/1"
            }
        }
    ]

GET
   URL    http://localhost:3000/riders


Response
{
    "status": "success",
    "message": "A particular Rider by supplying RiderId: 2",
    "RidersId": {
        "RidersId": 2,
        "Name": "Godwin Mensah"
    }
}

GET
 http://localhost:3000/drivers_closer/11

Response
{
    "status": "success",
    "message": "List of Drivers",
    "DriverList": [
        {
            "DriversId": 36,
            "Name": "New Savoiur Mensah",
            "LocationCode": "SAV1234",
            "Loc_Discription": "Dodowa Pilla 2",
            "Loc_Latitude": 7,
            "Loc_Longitude": 9,
            "Distance": 2234,
            "request": {
                "type": "GET",
                "url": "http://localhost:1337/drivers/36"
            }
        }
    ]
 


 GET
 http://localhost:3000/drivers

    "status": "success",
    "message": "List of Drivers",
    "DriverList": [
        {
            "DriversId": 1,
            "Name": "peter",
            "LocationCode": "ASC1234",
            "Loc_Discription": "3",
            "Loc_Latitude": -2,
            "Loc_Longitude": -9,
            "request": {
                "type": "GET",
                "url": "http://localhost:1337/drivers/1"
            }
        }
    ]

POST 
 http://localhost:3000/drivers

Request  Body
{
"Name":"New Savoiur Mensah",
"LocationCode":"SAV1234",
"Loc_Discription":"Dodowa Pilla 2",
"Loc_Latitude":"236",
"Loc_Longitude":"9"
}

Response
{
    "status": "success",
    "message": "Driver Created successfully"
}



POST 
 http://localhost:3000/riders

Request Body
{
"RidersId":"2",
"DriversId":"11",
"Description":"NEW1234",
"Dest_Latitude":"16",
"Dest_Longitude":"4"
}

Response
{
    "status": "success",
    "message": "Trip created successfully"
}




