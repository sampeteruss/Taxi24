﻿var sqlite3 = require('sqlite3').verbose();
function DBConnPost() {

    var db = new sqlite3.Database(process.env.DB);
    return db;
}

module.exports = DBConnPost;

