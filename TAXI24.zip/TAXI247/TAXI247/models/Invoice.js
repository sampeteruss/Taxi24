﻿
const InvoiceModel = {
    InvoiceId: Number,
    TripId: String,
    Amount: String,
    Driver: String,
    Rider: Number,
    StartDateTime: String,
    EndDateTime: String
};


module.exports = { Invoice: InvoiceModel };
