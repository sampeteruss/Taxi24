﻿
const DriverModel = {
    DriversId: Number,
    Name: String,
    LocationCode: String,
    Loc_Discription: String,
    Loc_Latitude: Number,
    Loc_Longitude: Number 
};

module.exports = {Driver: DriverModel};