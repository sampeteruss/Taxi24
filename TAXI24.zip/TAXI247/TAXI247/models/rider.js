﻿const RiderModel = {
    RidersId: Number,
    Name: String
   };

module.exports = { Rider: RiderModel};