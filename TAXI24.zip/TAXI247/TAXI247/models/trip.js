﻿const TripModel = {
    TripsId: Number,
    RiderId: Number,
    DriversId: Number,
    Dest_Latitude: Number,
    Dest_Longitude: Number,
    Description: String,
    StartDateTime: Date,
    EndDateTime: Date,
    TripEnded: String
};



module.exports = { Trip: TripModel};