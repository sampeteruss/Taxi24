﻿
'use strict';
var express = require('express');
var router = express.Router();
var Invoice = require('../models/invoice');
var DBCon = require('../models/DBConnect');
var conf = require('dotenv').config();


router.get('/', function (req, res) {
    GetInvoiceList(function (recordset) {
        Invoice = recordset; //assigning the result to the Invoice Module
        if (Invoice) {
            res.status(200).json({    //returning JSON response 
                status: 'success',
                message: 'List of Invoices',
                InvoiceList: Invoice.map(doc => {
                    return {
                        InvoiceId: doc.InvoiceId,
                        TripId: doc.TripId,
                        Amount: doc.Amount,
                        Driver: doc.Driver,
                        Rider: doc.Rider,
                        StartDateTime: doc.StartDateTime,
                        EndDateTime: doc.EndDateTime,
                        request: {
                            type: "GET",
                            url: process.env.BaseURL+'/Invoices/' + doc.InvoiceId.toString()
                        }
                    };
                })
            });
        }
        else {
            res.status(200).json({    //returning JSON response 
                status: 'failed',
                message: 'no Invoice found',
                InvoiceList: Invoice
            });
        }

    });
});

router.get('/:InvoicesId', (req, res, next) => {   
    var id = '';
    if (req.params.InvoicesId !== undefined) {
        id = req.params.InvoicesId;
    }
    Invoice={
          InvoicesId: id
        };
    GetInvoiceById(Invoice.InvoicesId, function (recordset) {
        Invoice = recordset; //assigning the result to the Invoice Module
        if (recordset) {
            res.status(200).json({
                status: 'success',
                message: 'A particular Invoice by supplying InvoiceId: ' + Invoice.InvoicesId,
                InvoiceById: Invoice
            });
        }
        else {
            res.status(200).json({
                status: 'failed',
                message: 'Invoice not seen',
                InvoiceById: Invoice
            });
        }

    });
});

router.patch('/:InvoicesId', (req, res, next) => {
    
    Invoice = {
        InvoicesId: req.params.InvoicesId,
        Name: req.body.Name,
        LocationId: req.body.LocationId,
        CurrentDistance: req.body.CurrentDistance
    };
    
    UpdateInvoice(Invoice, function (result) {

        if (result) {
            res.status(200).json({
                status: 'success',
                message: result
            });
        }
        else {
            res.json({
                status: 'failed',
                message: 'No encouraging response please try again'
            });
        }

    });

    


});


router.delete('/:InvoicesId', (req, res, next) => {

    DeleteInvoice(Invoice, function (result) {

        if (result) {
            res.status(200).json({
                status: 'success',
                message: result
            });
        }
        else {
            res.json({
                status: 'failed',
                message: 'No encouraging response please try again'
            });
        }

    });




});



/*
 * ---------------------------------------------------------------------------------
 * A Function GetInvoiceList which retrieved all Invoices using the Post method
 * @param {any} callback  Callback to display the resortSet
 * ---------------------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function GetInvoiceList(callback) {
     new DBCon().all('Select * from Invoice', [], (err, rows) => {
        if (err) {
            throw err;
        }
        console.log(JSON.stringify(rows));
        callback(rows);
    });
    new DBCon().close();
}


/*
 * ------------------------------------------------------------------------
 * A Function GetInvoiceById which retrieved a Invoice by InvoiceId
 * @param {any} InvoiceId  to receive the ID
 * @param {any} callback  Callback to display the resortSet  
 *-------------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function GetInvoiceById(InvoiceId,callback) {

    var sql = 'Select * from Invoice where InvoiceId=?';
     new DBCon().get(sql, [InvoiceId], (err, row) => {
         if (err) {
             callback(err.message);
         }
         else {
        callback(row);
        console.log(JSON.stringify(row));
         }

       }); 
}


/*
 * ------------------------------------------------------------------------
 * A FUNCRION TO ADD InvoiceS
 * @param {any} Invoice object having all the Attributes of the Invoice
 * @param {any} callback  call back for the result
 * ------------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function CreateInvoice(Invoice,callback) {

    new DBCon().serialize(function () {
        var stmt = new DBCon().prepare('Insert into Invoices(Name,LocationCode,Loc_Discription,Loc_Latitude,Loc_Longitude) values (?,?,?,?,?)');
        stmt.run(Invoice.Name, Invoice.LocationCode, Invoice.Loc_Discription, Invoice.Loc_Latitude, Invoice.Loc_Longitude,function (err) {
           if (err) {
              callback('Error '+err.message);
            }
           else {
                   if (stmt.changes > 0) {
                   callback('Invoice Created Successfully');
                   }
                   else {
                   callback('Insertion failed Please try again');
                   }
              }       
           stmt.finalize();
         });

    });
}

 
/* 
 * ---------------------------------------------------------------------
 * A FUNCTION TO IMPLEMENT THE PATCH/UPDATE A Invoice
 * @param {any} Invoice  Invoice Model as an object
 * @param {any} callback  callback service
 * ---------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function UpdateInvoice(Invoice,callback) {

    new DBCon().serialize(function () {

        //Check the Module and build the SQL message by eliminating fields or data that is not passed
        var sql = 'Update Invoice set ';
        if (Invoice.Name !== undefined) {
            sql = sql + 'Name=\'' + Invoice.Name+'\',';
        }
        if (Invoice.CurrentDistance !== undefined) {
            sql = sql + ' CurrentDistance=' + Invoice.CurrentDistance+',';
        }
        if (Invoice.LocationId !== undefined) {
            sql = sql + ' LocationId=\'' + Invoice.LocationId+'\',';
        }
        sql = sql.substring(0,sql.length-1) + ' where InvoicesId=?';
        var stmt = new DBCon().prepare(sql);
        stmt.run(Invoice.InvoicesId, function (err) {
            if (err) {
                callback('Error ' + err.message);
            }
            else {
                if (stmt.changes > 0) {
                    callback('Invoice Updated Successfully');
                }
                else {
                    callback('There is no update done to this Record');
                }
            }
        stmt.finalize();
        });

    });
}
 

/* 
 * ---------------------------------------------------------------------
 * A FUNCTION TO DROP THE Invoice
 * @param {any} Invoice  Invoice Model as an object
 * @param {any} callback  callback service
 * ---------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function DeleteInvoice(InvoiceId, callback) {

    new DBCon().serialize(function () {

        //Check the Module and build the SQL message by eliminating fields or data that is not passed
        var sql = 'Delete from Invoice where InvoiceId=' + InvoiceId;
        stmt.run(Invoice.InvoicesId, function (err) {
            if (err) {
                callback('Error ' + err.message);
            }
            else {
                if (stmt.changes > 0) {
                    callback('Invoice Deleted Successfully');
                }
                else {
                    callback('There is no update done to this Record');
                }
            }
            stmt.finalize();
        });

    });
}



module.exports = router;
