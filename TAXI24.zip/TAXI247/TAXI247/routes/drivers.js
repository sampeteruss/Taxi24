﻿
'use strict';
var express = require('express');
var router = express.Router();
var Driver = require('../models/driver');
var DBCon = require('../models/DBConnect');
var conf = require('dotenv').config();


router.get('/', function (req, res) {
    GetDriverList(function (recordset) {
        Driver = recordset; //assigning the result to the Driver Module
        if (Driver) {
            res.status(200).json({    //returning JSON response 
                status: 'success',
                message: 'List of Drivers',
                DriverList: Driver.map(doc => {
                    return {
                        DriversId: doc.DriversId,
                        Name: doc.Name,
                        LocationCode: doc.LocationCode,
                        Loc_Discription: doc.Loc_Discription,
                        Loc_Latitude: doc.Loc_Latitude,
                        Loc_Longitude: doc.Loc_Longitude,
                        request: {
                            type: "GET",
                            url: process.env.BaseURL+'/drivers/' + doc.DriversId.toString()
                        }
                    };
                })
            });
        }
        else {
            res.status(200).json({    //returning JSON response 
                status: 'failed',
                message: 'no driver found',
                DriverList: Driver
            });
        }

    });
});

router.get('/?DriversId :DriversId', (req, res, next) => {   
    var id = '';
    if (req.params.DriversId !== undefined) {
        id = req.params.DriversId;
    }
    Driver={
          DriversId: id
        };
    GetDriverById(Driver.DriversId, function (recordset) {
        Driver = recordset; //assigning the result to the Driver Module
        if (recordset) {
            res.status(200).json({
                status: 'success',
                message: 'A particular Driver by supplying DriverId: ' + Driver.DriversId,
                DriverById: Driver
            });
        }
        else {
            res.status(200).json({
                status: 'failed',
                message: 'Driver not seen',
                DriverById: Driver
            });
        }

    });
});

router.post('/', (req, res, next) => {
    var loc = '';
    var dname = 'Unknown';
    var loc_d = '';
    var loc_la = '';
    var loc_lg = '';
    if (req.body.LocationCode !== undefined) {
        loc = req.body.LocationCode;
    }
    if (req.body.Loc_Discription !== undefined) {
        loc_d = req.body.Loc_Discription;
    }
    if (req.body.Loc_Latitude !== undefined) {
        loc_la = req.body.Loc_Latitude;
    }
    if (req.body.Loc_Longitude !== undefined) {
        loc_lg = req.body.Loc_Longitude;
    }
    if (req.body.Name !== undefined) {
        dname = req.body.Name;
    }
    Driver = {
        Name: dname,
        LocationCode: loc,
        Loc_Discription: loc_d,
        Loc_Latitude: loc_la, 
        Loc_Longitude: loc_lg 
    };
    CreateDriver(Driver, function (result) {
        if (result.substring(0, 5) !== 'Error'){
            res.status(200).json({
                status: 'success',
                message: result
            });
        }
        else if (result.substring(0, 5) === 'Error') {
            res.status(200).json({
                            status: 'failed',
                            message: result
                        });
        }
        else {
            res.json({
                status: 'failed',
                message: 'Driver not added'
            });
        }
    });
});

router.patch('/:DriversId', (req, res, next) => {
    
    Driver = {
        DriversId: req.params.DriversId,
        Name: req.body.Name,
        LocationId: req.body.LocationId,
        CurrentDistance: req.body.CurrentDistance
    };
    
    UpdateDriver(Driver, function (result) {

        if (result) {
            res.status(200).json({
                status: 'success',
                message: result
            });
        }
        else {
            res.json({
                status: 'failed',
                message: 'No encouraging response please try again'
            });
        }

    });

    


});
/*
router.delete('/:driverId', (req, res, nexr) => {
    res.status(200).json({
        message: 'Deleted Driver'
    });
});



    
    /////////////////////////////////////
    var bb = sDriver.CreateDriver(repName, relocation);
        res.status(200).json({
        message: 'Handling Post to Driver',
            createdDriver: bb

            ////////////////////////////
    });
});

*/




/*
 * ---------------------------------------------------------------------------------
 * A Function GetDriverList which retrieved all Drivers using the Post method
 * @param {any} callback  Callback to display the resortSet
 * ---------------------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function GetDriverList(callback) {
     new DBCon().all('Select * from Drivers', [], (err, rows) => {
        if (err) {
            throw err;
        }
        console.log(JSON.stringify(rows));
        callback(rows);
    });
    new DBCon().close();
}


/*
 * ------------------------------------------------------------------------
 * A Function GetDriverById which retrieved a Driver by DriverId
 * @param {any} DriverId  to receive the ID
 * @param {any} callback  Callback to display the resortSet  
 *-------------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function GetDriverById(DriverId,callback) {

    var sql = 'Select * from Drivers where DriversId=?';
     new DBCon().get(sql, [DriverId], (err, row) => {
         if (err) {
             callback(err.message);
         }
         else {
        callback(row);
        console.log(JSON.stringify(row));
         }

       }); 
}


/*
 * ------------------------------------------------------------------------
 * A FUNCRION TO ADD DRIVERS
 * @param {any} Driver object having all the Attributes of the Driver
 * @param {any} callback  call back for the result
 * ------------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function CreateDriver(Driver,callback) {

    new DBCon().serialize(function () {
        var stmt = new DBCon().prepare('Insert into Drivers(Name,LocationCode,Loc_Discription,Loc_Latitude,Loc_Longitude) values (?,?,?,?,?)');
        stmt.run(Driver.Name, Driver.LocationCode, Driver.Loc_Discription, Driver.Loc_Latitude, Driver.Loc_Longitude,function (err) {
           if (err) {
              callback('Error '+err.message);
            }
           else {
                   if (stmt.changes > 0) {
                   callback('Driver Created Successfully');
                   }
                   else {
                   callback('Insertion failed Please try again');
                   }
              }       
           stmt.finalize();
         });

    });
}

 
/* 
 * ---------------------------------------------------------------------
 * A FUNCTION TO IMPLEMENT THE PATCH/UPDATE A DRIVER
 * @param {any} Driver  Driver Model as an object
 * @param {any} callback  callback service
 * ---------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function UpdateDriver(Driver,callback) {

    new DBCon().serialize(function () {

        //Check the Module and build the SQL message by eliminating fields or data that is not passed
        var sql = 'Update Drivers set ';
        if (Driver.Name !== undefined) {
            sql = sql + 'Name=\'' + Driver.Name+'\',';
        }
        if (Driver.CurrentDistance !== undefined) {
            sql = sql + ' CurrentDistance=' + Driver.CurrentDistance+',';
        }
        if (Driver.LocationId !== undefined) {
            sql = sql + ' LocationId=\'' + Driver.LocationId+'\',';
        }
        sql = sql.substring(0,sql.length-1) + ' where DriversId=?';
        var stmt = new DBCon().prepare(sql);
        stmt.run(Driver.DriversId, function (err) {
            if (err) {
                callback('Error ' + err.message);
            }
            else {
                if (stmt.changes > 0) {
                    callback('Driver Updated Successfully');
                }
                else {
                    callback('There is no update done to this Record');
                }
            }
        stmt.finalize();
        });

    });
}
 



module.exports = router;
