﻿'use strict';
var express = require('express');
var router = express.Router();
var Driver = require('../models/driver');
var DBCon = require('../models/DBConnect');
var conf = require('dotenv').config();
var GeoPoint = require('geopoint');

router.get('/:Location', (req, res, next) => {   
    var lat_long = ',';
    if (req.params.Location !== undefined) {
        lat_long = req.params.Location;
    }
    var splitString = lat_long.split(',');
    var latitude = splitString[0];
    var longitude = splitString[1];
    GetAvailableDriverById(latitude, longitude, function (recordset) {
        Driver = recordset; //assigning the result to the Driver Module
        if (recordset) {
            res.status(200).json({    //returning JSON response 
                status: 'success',
                message: 'List of Drivers',
                DriverList: Driver.map(doc => {
                    return {
                        DriversId: doc.DriversId,
                        Name: doc.Name,
                        LocationCode: doc.LocationCode,
                        Loc_Discription: doc.Loc_Discription,
                        Loc_Latitude: doc.Loc_Latitude,
                        Loc_Longitude: doc.Loc_Longitude,
                        Distance: doc.Distance,
                        request: {
                            type: "GET",
                            url: process.env.BaseURL + '/drivers/' + doc.DriversId.toString()
                        }
                    };
                })
            });
        }
        else {
            res.status(200).json({
                status: 'failed',
                message: 'Driver not seen',
                DriverById: Driver
            });
        }

    });
});

router.get('/', function (req, res) {
    GetAllAvailableDrivers(function (recordset) {
        Driver = recordset; //assigning the result to the Driver Module
        if (Driver) {
            res.status(200).json({    //returning JSON response 
                status: 'success',
                message: 'List of Drivers',
                DriverList: Driver.map(doc => {
                    return {
                        DriversId: doc.DriversId,
                        Name: doc.Name,
                        LocationCode: doc.LocationCode,
                        Loc_Discription: doc.Loc_Discription,
                        Loc_Latitude: doc.Loc_Latitude,
                        Loc_Longitude: doc.Loc_Longitude,
                        request: {
                            type: "GET",
                            url: process.env.BaseURL + '/drivers/' + doc.DriversId.toString()
                        }
                    };
                })
            });
        }
        else {
            res.status(200).json({    //returning JSON response 
                status: 'failed',
                message: 'no driver found',
                DriverList: Driver
            });
        }

    });
});



/*
 * ---------------------------------------------------------------------------------
 * A Function GetAllAvailableDrivers which retrieved all Drivers which are not assigned to a trip
 * @param {any} callback  Callback to display the resortSet
 * ---------------------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function GetAllAvailableDrivers(callback) {
    new DBCon().all('select Drivers.DriversId,Drivers.Name,Drivers.LocationCode,Drivers.Loc_Discription,case when Current_Location.Latitude is null then Drivers.Loc_Latitude else Current_Location.Latitude end  Loc_Latitude,case when Current_Location.Longitude is null then Drivers.Loc_Longitude else Current_Location.Longitude end  Loc_Longitude from Drivers left join Current_Location on Drivers.DriversId =Current_Location.DriversId where Drivers.DriversId  not in (select driversid from trips where TripEnded =\'No\')', [], (err, rows) => {
        if (err) {
            throw err;
        }
        console.log(JSON.stringify(rows));
        callback(rows);
    });
    new DBCon().close();
}


/*
 * ------------------------------------------------------------------------
 * A Function GetAvailableDriverById which retrieved available Driver by DriverId
 * @param {any} Latitude  
 * @param {any} Longitude  
 * @param {any} callback  Callback to display the resortSet  
 *-------------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */

function GetAvailableDriverById(latitude,longitude,callback) {
    new DBCon().all('select Drivers.DriversId,Drivers.Name,Drivers.LocationCode,Drivers.Loc_Discription,case when Current_Location.Latitude is null then Drivers.Loc_Latitude else Current_Location.Latitude end  Loc_Latitude,case when Current_Location.Longitude is null then Drivers.Loc_Longitude else Current_Location.Longitude end  Loc_Longitude from Drivers left join Current_Location on Drivers.DriversId =Current_Location.DriversId where Drivers.DriversId  not in (select driversid from trips where TripEnded =\'No\')', [], (err, rows) => {
        if (err) {
            throw err;
        }
        var rowArry = [];
        var point1 = 0;
        var point2 = 0;
        var count = 0;
        var distance = 0;
            rows.forEach((row) => {
            point1 = new GeoPoint(Number(latitude), Number(longitude));
            point2 = new GeoPoint(Number(row.Loc_Latitude), Number(row.Loc_Longitude));
            distance = point1.distanceTo(point2, true);
           // distance = 3; used to test the distance value since is diff to guess it
            if (Number(distance) <= 3) {
                var c = {
                    DriversId: row.DriversId,
                    Name: row.Name,
                    LocationCode: row.LocationCode,
                    Loc_Discription: row.Loc_Discription,
                    Loc_Latitude: row.Loc_Latitude,
                    Loc_Longitude: row.Loc_Longitude,
                    Distance: distance
                };
                rowArry[count] = c;
                count++;    
                   c = null;
            }         
                
             
        });
        callback(rowArry);
        console.log(JSON.stringify(rows));       
    });
    new DBCon().close();
}


 



module.exports = router;
