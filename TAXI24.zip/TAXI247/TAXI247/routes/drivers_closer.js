﻿'use strict';
var express = require('express');
var router = express.Router();
var Driver = require('../models/driver');
var DBCon = require('../models/DBConnect');
var conf = require('dotenv').config();
var GeoPoint = require('geopoint');

router.get('/:DriversId', (req, res, next) => {   
    var lat_long = ' ';
    if (req.params.DriversId !== undefined) {
        lat_long = req.params.DriversId;
    }
   
    GetCloserDriverById(lat_long, function (recordset) {
        Driver = recordset; //assigning the result to the Driver Module
        if (recordset) {
            res.status(200).json({    //returning JSON response 
                status: 'success',
                message: 'List of Drivers',
                DriverList: Driver.map(doc => {
                    return {
                        DriversId: doc.DriversId,
                        Name: doc.Name,
                        LocationCode: doc.LocationCode,
                        Loc_Discription: doc.Loc_Discription,
                        Loc_Latitude: doc.Loc_Latitude,
                        Loc_Longitude: doc.Loc_Longitude,
                        Distance: Math.round(doc.Distance),
                        request: {
                            type: "GET",
                            url: process.env.BaseURL + '/drivers/' + doc.DriversId.toString()
                        }
                    };
                })
            });
        }
        else {
            res.status(200).json({
                status: 'failed',
                message: 'Driver not seen',
                DriverById: Driver
            });
        }

    });
});

//router.get('/', function (req, res) {
//    GetAllAvailableDrivers(function (recordset) {
//        Driver = recordset; //assigning the result to the Driver Module
//        if (Driver) {
//            res.status(200).json({    //returning JSON response 
//                status: 'success',
//                message: 'List of Drivers',
//                DriverList: Driver.map(doc => {
//                    return {
//                        DriversId: doc.DriversId,
//                        Name: doc.Name,
//                        LocationCode: doc.LocationCode,
//                        Loc_Discription: doc.Loc_Discription,
//                        Loc_Latitude: doc.Loc_Latitude,
//                        Loc_Longitude: doc.Loc_Longitude,
//                        request: {
//                            type: "GET",
//                            url: process.env.BaseURL + '/drivers/' + doc.DriversId.toString()
//                        }
//                    };
//                })
//            });
//        }
//        else {
//            res.status(200).json({    //returning JSON response 
//                status: 'failed',
//                message: 'no driver found',
//                DriverList: Driver
//            });
//        }

//    });
//});



/*
 * ---------------------------------------------------------------------------------
 * A Function GetAllAvailableDrivers which retrieved all Drivers which are not assigned to a trip
 * @param {any} callback  Callback to display the resortSet
 * ---------------------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function GetCloserDrivers(Lat_Log, DriversId, callback) {
    new DBCon().all('select Drivers.DriversId,Drivers.Name,Drivers.LocationCode,Drivers.Loc_Discription,case when Current_Location.Latitude is null then Drivers.Loc_Latitude else Current_Location.Latitude end  Loc_Latitude,case when Current_Location.Longitude is null then Drivers.Loc_Longitude else Current_Location.Longitude end  Loc_Longitude from Drivers left join Current_Location on Drivers.DriversId =Current_Location.DriversId',[],(err, rows) => {
        if (err) {
            throw err;
        }
        var rowArry2 = [];


        var splitString = Lat_Log.split(',');
        var latitude = splitString[0];
        var longitude = splitString[1];

        var point1 = 0;
        var point2 = 0;
        var count = 0;
        var distance = 0;
        rows.forEach((row) => {
             point1 = new GeoPoint(Number(latitude), Number(longitude));
            point2 = new GeoPoint(Number(row.Loc_Latitude), Number(row.Loc_Longitude));
            distance = point1.distanceTo(point2, true);
            // distance = 3; used to test the distance value since is diff to guess it
           // var distModule = Number(OriginalDistance) - Number(distance);      
            var c = {
                DriversId: row.DriversId,
                Name: row.Name,
                LocationCode: row.LocationCode,
                Loc_Discription: row.Loc_Discription,
                Loc_Latitude: row.Loc_Latitude,
                Loc_Longitude: row.Loc_Longitude,
                Distance: distance
            };
            if (distance < rowArry2[0]) {
                rowArry2[0] = c;
            }
            if (distance > rowArry2[0] && distance < rowArry2[1]) {
                rowArry2[1] = c;
            }
            if (distance > rowArry2[0] && distance > rowArry2[1] && distance < rowArry2[1]) {
                rowArry2[2] = c;
            }
            else {
                rowArry2[3] = c;
            }

           //  = c;
            count++;
            c = null;

        });
        // 
        console.log(JSON.stringify(rowArry2));
       
       // rowArry2.sort((a, b) => (a.last_nom > b.last_nom) ? 1 : ((b.last_nom > a.last_nom) ? -1 : 0));
       // callback(rowArry2);
        res.status(200).json({    //returning JSON response 
            status: 'success',
            message: 'List of Drivers',
            DriverList: rowArry2.map(doc => {
                return {
                    DriversId: doc.DriversId,
                    Name: doc.Name,
                    LocationCode: doc.LocationCode,
                    Loc_Discription: doc.Loc_Discription,
                    Loc_Latitude: doc.Loc_Latitude,
                    Loc_Longitude: doc.Loc_Longitude,
                    Distance: Math.round(doc.Distance,2),
                    request: {
                        type: "GET",
                        url: process.env.BaseURL + '/drivers/'  + doc.DriversId.toString()
                    }
                };
            })
        });
      
    });
    new DBCon().close();
}


/*
 * ------------------------------------------------------------------------
 * A Function GetAvailableDriverById which retrieved available Driver by DriverId
 * @param {any} Latitude  
 * @param {any} Longitude  
 * @param {any} callback  Callback to display the resortSet  
 *-------------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */

function GetCloserDriverById(DriverId,callback) {
    new DBCon().all('select Drivers.DriversId,Drivers.Name,Drivers.LocationCode,Drivers.Loc_Discription,case when Current_Location.Latitude is null then Drivers.Loc_Latitude else Current_Location.Latitude end  Loc_Latitude,case when Current_Location.Longitude is null then Drivers.Loc_Longitude else Current_Location.Longitude end  Loc_Longitude from Drivers left join Current_Location on Drivers.DriversId =Current_Location.DriversId  WHERE Drivers.DriversId='+DriverId, [], (err, rows) => {
        if (err) {
            throw err;
        }
        var rowArry = [];
        var point1 = 0;
        var point2 = 0;
        var count = 0;
        var distance = 0;
            rows.forEach((row) => {
           // point1 = new GeoPoint(Number(latitude), Number(longitude));
          //  point2 = new GeoPoint(Number(row.Loc_Latitude), Number(row.Loc_Longitude));
           // distance = point1.distanceTo(point2, true);
           // distance = 3; used to test the distance value since is diff to guess it
           
                var c = {
                    DriversId: row.DriversId,
                    Latitude: row.Loc_Latitude,
                    Longitude: row.Loc_Longitude
                };
                rowArry[count] = c;
                count++;    
                   c = null;             
         
        });

        //--------------------------------------------- 
        new DBCon().all('select Drivers.DriversId,Drivers.Name,Drivers.LocationCode,Drivers.Loc_Discription,case when Current_Location.Latitude is null then Drivers.Loc_Latitude else Current_Location.Latitude end  Loc_Latitude,case when Current_Location.Longitude is null then Drivers.Loc_Longitude else Current_Location.Longitude end  Loc_Longitude from Drivers left join Current_Location on Drivers.DriversId =Current_Location.DriversId', [], (err, rows) => {
            if (err) {
                throw err;
            }
            var rowArry2 = [];

          
           // var splitString = Lat_Log.split(',');
            var latitude = rows[0].Loc_Latitude;//splitString[0];
            var longitude = rows[0].Loc_Longitude;//splitString[1];

            var point1 = 0;
            var point2 = 0;
            var count = 0;
            var distance = 0;
            rows.forEach((row) => {
                point1 = new GeoPoint(Number(latitude), Number(longitude));
                point2 = new GeoPoint(Number(row.Loc_Latitude), Number(row.Loc_Longitude));
                distance = point1.distanceTo(point2, true);
                // distance = 3; used to test the distance value since is diff to guess it
                // var distModule = Number(OriginalDistance) - Number(distance);      
                var c = {
                    DriversId: row.DriversId,
                    Name: row.Name,
                    LocationCode: row.LocationCode,
                    Loc_Discription: row.Loc_Discription,
                    Loc_Latitude: row.Loc_Latitude,
                    Loc_Longitude: row.Loc_Longitude,
                    Distance: distance
                };
                if (Number(distance) < rowArry2[0]) {

                    if (rowArry2[0] < rowArry2[1]) {
                        rowArry2[1] = rowArry2[0];                      
                    }
                    else if(rowArry2[0] < rowArry2[1]) {
                        rowArry2[1] = rowArry2[0];
                        rowArry2[0] = c;
                    }
                     rowArry2[0] = c;
                }
                else {
                    if (Number(distance) < rowArry2[1]) {
                        rowArry2[1] = c;
                    }
                    else {
                        if (Number(distance) < rowArry2[2]) {
                            rowArry2[2] = c;
                        }
                        else {
                            rowArry2[3] = c;
                        }
                    }
                }

                //  = c;
                count++;
                c = null;

            });
            // 
            console.log(JSON.stringify(rowArry2));

            // rowArry2.sort((a, b) => (a.last_nom > b.last_nom) ? 1 : ((b.last_nom > a.last_nom) ? -1 : 0));
              callback(rowArry2);
            res.status(200).json({    //returning JSON response 
                status: 'success',
                message: 'List of Drivers',
                DriverList: rowArry2.map(doc => {
                    return {
                        DriversId: doc.DriversId,
                        Name: doc.Name,
                        LocationCode: doc.LocationCode,
                        Loc_Discription: doc.Loc_Discription,
                        Loc_Latitude: doc.Loc_Latitude,
                        Loc_Longitude: doc.Loc_Longitude,
                        Distance: doc.Distance,
                        request: {
                            type: "GET",
                            url: process.env.BaseURL + '/drivers/' //+ doc.DriversId.toString()
                        }
                    };
                })
            });

        });
        new DBCon().close();

        //----------------------------------------------------------------------------------




       // callback(GetCloserDrivers(rows[0].Loc_Latitude + ',' + rows[0].Loc_Longitude, rows[0].DriversId, callback));
                     
       // console.log(JSON.stringify(rows));       
    });
    new DBCon().close();
}


 



module.exports = router;
