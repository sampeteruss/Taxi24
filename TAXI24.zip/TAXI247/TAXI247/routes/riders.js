﻿
'use strict';
var express = require('express');
var router = express.Router();
var Rider = require('../models/rider');
var DBCon = require('../models/DBConnect');
var conf = require('dotenv').config();


router.get('/', function (req, res) {
    GetAllRidersList(function (recordset) {
        Rider = recordset; //assigning the result to the Rider Module
        if (Rider) {
            res.status(200).json({    //returning JSON response 
                status: 'success',
                message: 'List of Riders',
                RiderList: Rider.map(doc => {
                    return {
                        RidersId: doc.RidersId,
                        Name: doc.Name,
                        request: {
                            type: "GET",
                            url: process.env.BaseURL + '/riders/' + doc.RidersId.toString()
                        }
                    };
                })
            });
        }
        else {
            res.status(200).json({    //returning JSON response 
                status: 'failed',
                message: 'no Rider found',
                RiderList: Rider
            });
        }

    });
});

router.get('/:RidersId', (req, res, next) => {   
    var id = '';
    if (req.params.RidersId !== undefined) {
        id = req.params.RidersId;
    }
    Rider={
        RidersId: id
        };
    GetRiderById(Rider.RidersId, function (recordset) {
        Rider = recordset; //assigning the result to the Rider Module
        if (recordset) {
            res.status(200).json({
                status: 'success',
                message: 'A particular Rider by supplying RiderId: ' + Rider.RidersId,
                RidersId: Rider
            });
        }
        else {
            res.status(200).json({
                status: 'failed',
                message: 'Rider not seen',
                RidersId: Rider
            });
        }

    });
});



/*
 * ---------------------------------------------------------------------------------
 * A Function GetAllRidersList which retrieved all Riders using the Post method
 * @param {any} callback  Callback to display the resortSet
 * ---------------------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function GetAllRidersList(callback) {
    new DBCon().all('Select * from Riders', [], (err, rows) => {
        if (err) {
            throw err;
        }
        console.log(JSON.stringify(rows));
        callback(rows);
    });
    new DBCon().close();
}


/*
 * ------------------------------------------------------------------------
 * A Function GetRiderById which retrieved a Rider by RiderById
 * @param {any} RidersId  to receive the ID
 * @param {any} callback  Callback to display the resortSet  
 *-------------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function GetRiderById(RidersId,callback) {

    var sql = 'Select * from Riders where RidersId=?';
    new DBCon().get(sql, [RidersId], (err, row) => {
         if (err) {
             callback(err.message);
         }
         else {
        callback(row);
        console.log(JSON.stringify(row));
         }

       }); 
}


module.exports = router;
