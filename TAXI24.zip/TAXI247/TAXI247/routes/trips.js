﻿
'use strict';
var express = require('express');
var router = express.Router();
var Trip = require('../models/trip');
var DBCon = require('../models/DBConnect');
var conf = require('dotenv').config();


router.get('/', function (req, res) {
    GetAllActiveTrips(function (recordset) {
        Trip = recordset; //assigning the result to the Trip Module
        if (Trip) {
            res.status(200).json({    //returning JSON response 
                status: 'success',
                message: 'List of Available Trips',
                ActiveTrips: Trip.map(doc => {
                    return {
                        TripsId: doc.TripsId,
                        RiderId: doc.RiderId,
                        DriversId: doc.DriversId,
                        Dest_Latitude: doc.Dest_Latitude,
                        Dest_Longitude: doc.Dest_Longitude,
                        Description: doc.Description,
                        StartDateTime: doc.StartDateTime,
                        EndDateTime: doc.EndDateTime,
                        TripEnded: doc.TripEnded,
                        request: {
                            type: "GET",
                            url: process.env.BaseURL + '/trips/' + doc.TripsId.toString()
                        }
                    };
                })
            });
        }
        else {
            res.status(200).json({    //returning JSON response 
                status: 'failed',
                message: 'no Trip found',
                ActiveTrips: Trip
            });
        }

    });
});


router.post('/', (req, res, next) => {
    var RidersId = '';
    var dname = 'Unknown';
    var DriversId = '';
    var Dest_Latitude = '';
    var Dest_Longitude = '';
    var Description = '';
   // var StartDateTime = ; 
    var EndDateTime = ''; 
    var TripEnded = 'No'; 
  
    if (req.body.TripEnded !== undefined) {
        EndDateTime = req.body.TripEnded;
    }
    if (req.body.EndDateTime !== undefined) {
        EndDateTime = req.body.EndDateTime;
    }
    if (req.body.StartDateTime !== undefined) {
        StartDateTime = req.body.StartDateTime;
    }
    if (req.body.Description !== undefined) {
        Description = req.body.Description;
    }
    if (req.body.RidersId !== undefined) {
        RidersId = req.body.RidersId;
    }
    if (req.body.DriversId !== undefined) {
    DriversId = req.body.DriversId;
    }
if (req.body.Dest_Latitude !== undefined) {
    Dest_Latitude = req.body.Dest_Latitude;
    }
if (req.body.Dest_Longitude !== undefined) {
    Dest_Longitude = req.body.Dest_Longitude;
    }
    if (req.body.Name !== undefined) {
        dname = req.body.Name;
    }
    Trip = {
        RidersId: RidersId,
        DriversId: DriversId,
        Dest_Latitude: Dest_Latitude,
        Dest_Longitude: Dest_Longitude,
        Description: Description,
       // StartDateTime: StartDateTime,
        EndDateTime: EndDateTime,
        TripEnded: TripEnded
    };
    CreateTrip(Trip, function (result) {
        if (result.substring(0, 5) !== 'Error'){
            res.status(200).json({
                status: 'success',
                message: result
            });
        }
        else if (result.substring(0, 5) === 'Error') {
            res.status(200).json({
                            status: 'failed',
                            message: result
                        });
        }
        else {
            res.json({
                status: 'failed',
                message: 'Trip not created'
            });
        }
    });
});


/*
 * ------------------------------------------------------------------------
 * A FUNCRION TO END A TRIP
 * @param {any} Trip ID accepts as a parameter
 * @param {any} callback  call back for the result
 * ------------------------------------------------------------------------
 * Create Date: 28/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
router.patch('/:TripsId', (req, res, next) => {
        
    var TripsId = '0';
    if (req.params.TripsId !== undefined) {
        TripsId = req.params.TripsId;
    }
    UpdateTrip(TripsId, function (result) {

        if (result) {
            res.status(200).json({
                status: 'success',
                message: result
            });
        }
        else {
            res.json({
                status: 'failed',
                message: 'No encouraging response please try again'
            });
        }

    });

    


});
/*
router.delete('/:driverId', (req, res, nexr) => {
    res.status(200).json({
        message: 'Deleted Driver'
    });
});



    
    /////////////////////////////////////
    var bb = sDriver.CreateDriver(repName, relocation);
        res.status(200).json({
        message: 'Handling Post to Driver',
            createdDriver: bb

            ////////////////////////////
    });
});

*/




/*
 * ---------------------------------------------------------------------------------
 * A Function GetAllActiveTrips which retrieved all Active Trips
 * @param {any} callback  Callback to display the resortSet
 * ---------------------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function GetAllActiveTrips(callback) {
    new DBCon().all('Select * from Trips where TripEnded=\'No\'', [], (err, rows) => {
        if (err) {
            throw err;
        }
        console.log(JSON.stringify(rows));
        callback(rows);
    });
    new DBCon().close();
}


/*
 * ------------------------------------------------------------------------
 * A FUNCRION TO CREATE TRIP
 * @param {any} Trip object having all the Attributes of a Trip
 * @param {any} callback  call back for the result
 * ------------------------------------------------------------------------
 * Create Date: 27/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function CreateTrip(Trip,callback) {

    new DBCon().serialize(function () {
        var stmt = new DBCon().prepare('insert into Trips(RidersId,DriversId,TripEnded,StartDateTime,EndDateTime,Dest_Latitude,Dest_Longitude,Description) values(?,?,?,?,?,?,?,?)');
        stmt.run(Trip.RidersId, Trip.DriversId, Trip.TripEnded, Trip.StartDateTime, Trip.EndDateTime, Trip.Dest_Latitude, Trip.Dest_Longitude, Trip.Description,function (err) {
           if (err) {
              callback('Error '+err.message);
            }
           else {
                   if (stmt.changes > 0) {
                   callback('Trip Created Successfully');
                   }
                   else {
                   callback('Insertion failed Please try again');
                   }
              }       
           stmt.finalize();
         });

    });
}

 
/* 
 * ---------------------------------------------------------------------
 * A FUNCTION TO IMPLEMENT THE PATCH/UPDATE A Trip
 * @param {any} TripsId  accepted as a parameter
 * @param {any} callback  callback service
 * ---------------------------------------------------------------------
 * Create Date: 28/09/2019
 * Author:  Peter Mensah
 * Update:
 * Update Details:
 * Updated By:
 */
function UpdateTrip(TripsId,callback) {

    new DBCon().serialize(function () {

        //Check the Module and build the SQL message by eliminating fields or data that is not passed
        var sql = 'Update Trips set TripEnded=\'Yes\',EndDateTime=CURRENT_TIME where TripsId=?';
        var stmt = new DBCon().prepare(sql);
        stmt.run(TripsId, function (err) {
            if (err) {
                callback('Error ' + err.message);
            }
            else {
                if (stmt.changes > 0) {
                    callback('Trip Ended Successfully');
                }
                else {
                    callback('There is no update done to this Record');
                }
            }
        stmt.finalize();
        });

    });
}
 



module.exports = router;
