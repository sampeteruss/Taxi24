﻿var should = require("should");
var request = require("request");
var expect = require('chai').expect;
var baseUrl = Process.env.BaseURL;
var util = require('util');

describe('unit Testing Cases for Taxi24_by_7 interview Project (API Calls)', function () {
    it('▪ Get a list of all drivers', function (done) {
        request.get({ url: baseUrl + '/drivers' }, function (error, response, body) {
            var bodyobj = JSON.parse(body);
            expect(response.statuscode).to.equal(200);
            console.log(body);
            done();
        });

    });
    it('▪ Get a list of all available drivers', function (done) {
        request.get({ url: baseUrl + '/drivers_available' }, function (error, response, body) {
            var bodyobj = JSON.parse(body);
            expect(bodyobj.name).to.equal("Peter Mensah");
            expect(response.statuscode).to.equal(200);
            console.log(body);
            done();
        });

    });

    it('▪ Get a list of all available drivers within 3km for a specific location', function (done) {
        request.get({ url: baseUrl + '/drivers_available/0,0.002' }, function (error, response, body) {
            var bodyobj = JSON.parse(body);
            expect(bodyobj.name).to.equal("Peter Mensah");
            expect(response.statuscode).to.equal(200);
            console.log(body);
            done();
        });

    });
    it('▪ Get a specific driver by ID', function (done) {
        request.get({ url: baseUrl + '/drivers/1' }, function (error, response, body) {
            var bodyobj = JSON.parse(body);
            expect(bodyobj.name).to.equal("Peter Mensah");
            expect(response.statuscode).to.equal(200);
            console.log(body);
            done();
        });

    });
    it('▪ Create a new Trip request by assigning a driver to a rider', function (done) {
        request.get({ url: baseUrl + '/trip' }, function (error, response, body) {
            var bodyobj = JSON.parse(body);
            expect(response.statuscode).to.equal(200);
            console.log(body);
            done();
        });

    });
    it('▪ Complete a trip', function (done) {
        request.get({ url: baseUrl + '/trips' }, function (error, response, body) {
            var bodyobj = JSON.parse(body);
            expect(bodyobj.name).to.equal("Peter Mensah");
            expect(response.statuscode).to.equal(200);
            console.log(body);
            done();
        });

    });
    it('▪ Get a list of all active Trips', function (done) {
        request.get({ url: baseUrl + '/trips' }, function (error, response, body) {
            var bodyobj = JSON.parse(body);
            //expect(bodyobj.name).to.equal("Peter Mensah");
            expect(response.statuscode).to.equal(200);
            console.log(body);
            done();
        });

    });
    it('▪ Get a list of all riders', function (done) {
        request.get({ url: baseUrl + '/riders' }, function (error, response, body) {
            var bodyobj = JSON.parse(body);
            //expect(bodyobj.name).to.equal("Peter Mensah");
            expect(response.statuscode).to.equal(200);
            console.log(body);
            done();
        });

    });
    it('▪ Get a specific rider by ID', function (done) {
        request.get({ url: baseUrl + '/riders/1' }, function (error, response, body) {
            var bodyobj = JSON.parse(body);
            expect(bodyobj.name).to.equal("Saviour Mensah");
            expect(response.statuscode).to.equal(200);
            console.log(body);
            done();
        });

    });
    it('▪ For a specific driver, get a list of the 3 closest drivers', function (done) {
        request.get({ url: baseUrl + '/drivers_closer/1' }, function (error, response, body) {
            var bodyobj = JSON.parse(body);
            expect(bodyobj.name).to.equal("Peter Mensah"); //Peter is the Driver used
            expect(response.statuscode).to.equal(200);
            console.log(body);
            done();
        });

    });

});
